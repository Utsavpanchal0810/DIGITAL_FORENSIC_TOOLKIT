import requests
import time
import socket
import whois
from urllib.parse import urlparse
import ssl

url = input("\n Enter Website URL Example: (https://www.example.com): ").strip()

# ---------- RESPONSE TIME -----------

try:
    start = time.time()
    response = requests.get(url,timeout=10)
    end = time.time()

    response_time = round(end-start,3)
    print("Website Reachable")
    print("Status Code: ",response.status_code)
    print("Response Time: ",response_time)
except Exception as e:
    print("Unable to connect to website")
    print(e)
    exit()


# -------- HTTPS CHECK

if url.startswith("https://"):
    print("HTTPS ENABLED")
else:
    print("HTTPS NOT ENABLED")

# -------- DNS LOOKUP

domain = urlparse(url).netloc


try:
    ip = socket.gethostbyname(domain)
    print("Domain",domain)
    print("IP Address: ",ip)
except:
    print("Unable to resolve DNS")


# ------ SERVER INFORMATION

server = response.headers.get("Server")

if server:
    print("Server Banner",server)
else:
    print("Server Banner Hidden")


"""
    security headers
    robots.txt
    sitemap.xml
    redirection check
    whois
    ssl certificate
    cookies
    
"""

# ---------- SECURITY HEADERS
"""
    TOTAL 6 TYPES
        1. X-FRAME-OPTIONS --> PROTECT AGAINST ( CLICKJACKING )
            - NOT ALLOW TO PAGE BEING LOADED IN ANYKIND OF INFRAME
        2. CONTENT-SECURITY-POLICY --> RESTRICTION
        3. STRICT-TRANSPORT-SECURITY 00> 

"""

headers_to_check = [
    "Content-Security-Policy",
    "Strict-Transport-Security",
    "X-Frame-Options",
    "X-Content-Type-Options",
    "Referrer-Policy",
    "Permission-Policy"
]

score = 0

for h in headers_to_check:

    if h in response.headers:
        score+=1
        print("Header Found:",h)
    else:
        print(f"\n {h} is missing")

print("Score: ",score)


# --------- ROBOTS.TXT -----------

robots = url.rstrip("/")+ "/robots.txt"

try:

    res = requests.get(robots,timeout=5)
    print(res)

    if res.status_code == 200:
        print("robots.txt found")
    else:
        print("robots.txt not found")

except:
    print("unable to reach domain")


# --------- SITEMAP.XML


site = url.rstrip("/") + "/sitemap.xml"

try:

    res1 = requests.get(site,timeout=5)

    if res1.status_code == 200:
        print("SiteMap.xml found")
    else:
        print("Sitemap.xml not found")

except:
    print("Unable to check sitemap.xml")


# -----------  REDIRECT CHECK ------------

try:

    res2 = requests.get(url,allow_redirects=True)

    if len(res2.history):
        print("Redirection present")

        for redirect in res2.history:
            print("-->",redirect.status_code,redirect.url)
    else:
        print("No redirects available")


except:
    pass


# ----------- WHOIS ---------------


try:

    info = whois.whois(domain)

    print("Registar: ",info.registrar)
    print("Creation Date: ",info.creation_date)
    print("Expiry  Date: ",info.expiration_date)
except:
    print("whois information not available")


# ------------   COOKIES ------------------

cookies = response.cookies

if cookies:

    for cookie in cookies:
        print(f"Cookie: {cookie.name} ")

        if cookie.secure:
            print("Secure Flag is enabled")
        else:
            print("Secure Flag is missing")

        rest = cookie._rest

        if "HttpOnly" in rest:
            print("HttpOnly is Enabled")
        else:
            print("HttpOnly is Missing")


# --------------- SSL CHECK ----------------

try:

    context = ssl.create_default_context()

    with socket.create_connection((domain,443),timeout=5) as sock:
        with context.wrap_socket(sock,server_hostname=domain) as sscok:

            cert = sscok.getpeercert()

            print("SSL certificate found")

            print("\n Issuer: ")
            for i in cert["issuer"]:
                print(" ",i)

            print("\n Expiry: ",cert["notAfter"])
except:
    print("SSL certificate info not available")

"""

    PASSWORD
    
        1. HASHING
        2. 

"""