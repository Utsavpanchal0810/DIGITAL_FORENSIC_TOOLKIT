import socket
import time

print("Network Security Scanner")


target = input("Enter Domain Name: ")

try:
    ip = socket.gethostbyname(target)
    print("\n Target: ",target)
    print("\n Ip Address: ",ip)

except:
    print("Unable to resolve target")
    exit()


# --------------------- COMMON PORTS AND SERVICE
ports = {
    21:"FTP",
    22:"SSH",
    25:"SMTP",
    53:"DNS",
    80:"HTTP",
    110:"POP3",
    143:"IMAP",
    443:"HTTPS",
    3306:"MySQL",
    3389:"Remote Desktop"
}

open_ports = []

print("\n Checking Common Ports: ")

start = time.time()

for port , service in ports.items():

    # communication
    # tcp socket --> 1. ipv4 address , 2. type of protocol
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)

    s.settimeout(1)

    # connect_ex () --> 1. ip , port
    result = s.connect_ex((ip,port))



    if result == 0:
        print(f"Port {port} OPEN     {service}")
        open_ports.append((port,service))
    else:
        print(f"Port {port} CLOSED   {service}")

    s.close()

end = time.time()
print("\n Response time: ",end-start)


print("RISK ANALYSIS: ")

risk_table = {
    21:"High ( FTP is unencrypted) ",
    22:"Medium ( Secure if configured properly )",
    25:"Medium ( Mail Server )",
    53:"Low ( DNS Service )",
    80:"Low ( HTTP )",
    110:"Medium ( POP3 )",
    143:"Medium (IMAP)",
    443:"Low (HTTPS)",
    3306: "High ( Database should not be publicly exposed )",
    3389:"High ( Remote Desktop )"
}

if len(open_ports) == 0:
    print("No common ports are open")
else:

    for port,service in open_ports:
        print(f"{port}, {service} , {risk_table[port]}")



print("Network Security Report")

print("Target:     ",target)
print("Ip Address:  ",ip)
print("Ports Checked: ",len(ports))
print("Open Ports: ",len(open_ports))
print("Scan Time: ",round(end-start,2),"Seconds")

print("Scan Completed.................")