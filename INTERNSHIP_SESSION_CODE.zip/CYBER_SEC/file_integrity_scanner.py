"""

    step 1: ask user to enter folder path
    step 2: through loops will hash all files and store it in dictionary
    step 3: ask user to modify any file
    step 4: generate hash again and then compare

"""

# used to work with folders and file paths
import os
# use to generate SHA256 hashes
import hashlib

# ask user to enter folder path
folder = input("Enter Folder Path: ")

print(folder)

original_hash = {}

# visit every file or sub-folder inside folder
"""
    root ---> current folder
    folders ---> list of folders inside root
    files ---> list of files inside root

"""

for root , folders , files in os.walk(folder):

    # loop through all this files inside the folder
    for file in files:

        filepath = os.path.join(root,file)
        print(filepath)

        # open file in binary mode
        with open(filepath,"rb") as f:

            # read complete file
            data = f.read()

        # generate sha256 hash
        hash_value = hashlib.sha256(data).hexdigest()

        original_hash[filepath] = hash_value

        print(file)
        print(hash_value)
        print("-"*60)



print("\n Modify any file inside the folder and save it")
input("Please enter after modifying the file")

print("\n Checking File Integrity ..................")


for root , folders , files in os.walk(folder):
    for file in files:

        filepath = os.path.join(root,file)

        with open(filepath,"rb") as f:

            data = f.read()

            # generate new hash
            new_hash = hashlib.sha256(data).hexdigest()

            # compare new hash with original hash
            if original_hash[filepath] == new_hash:
                print(file,"--> safe")
            else:
                print(file,"--> modified")


print("\n File Integrity Check Completed....")