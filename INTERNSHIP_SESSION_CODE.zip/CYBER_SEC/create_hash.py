import hashlib

password = input("Enter Password").strip()

password_bytes = password.encode()

# MD5
md5_hash = hashlib.md5().hexdigest()
print("Original password: ",password)
print("MD5 Hashed Password: ",md5_hash)