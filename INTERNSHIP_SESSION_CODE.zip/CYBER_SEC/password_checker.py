import hashlib

import requests

print("Module 1 - Hash Identification")

sample_hash = input("Enter a Hash: ").strip()

if len(sample_hash) == 32:
    print("Possible Algorithm: MD5")
elif len(sample_hash) == 40:
    print("Possible Algorithm: SHA1")
elif len(sample_hash) == 64:
    print("Possible Algorithm: SHA256")
elif len(sample_hash) == 128:
    print("Possible Algorithm: SHA512")
else:
    print("Unknown hash")


print("MODULE 2 --- HASH VERIFICATION ")

# Mock Database
users = {
    "amit":hashlib.sha256("Hello@123".encode()).hexdigest(),
    "raj":hashlib.sha256("Python@123".encode()).hexdigest(),
    "Darshan":hashlib.sha256("Admin@123".encode()).hexdigest()
}

print(users)

username = input("Username: ")
password = input("Password: ")

if username in users:
    entered_hash = hashlib.sha256(password.encode()).hexdigest()

    print(entered_hash)

    if entered_hash == users[username]:
        print("Authentication Successful")
    else:
        print("Authentication Failed")
else:
    print("User not found")


print("MODULE 3: password leak checker")

password = input("Enter Password: ")

sha1 = hashlib.sha1(password.encode()).hexdigest().upper()

prefix = sha1[:5]
sufix = sha1[5:]

print("\n SHA1: ",sha1)
print("Prefix Sent: ",prefix)

url = f"https://api.pwnedpasswords.com/range/{prefix}"

try:

    response = requests.get(url,timeout=5)
    # print(response.text)
    found = False

    for line in response.text.splitlines():
        hash_suffix , count = line.split(":")
        if hash_suffix==sufix:
            print("Password found",count)
            found = True
            break

    if not found:
        print("Password not found in known breaches")
except:
    print("Api Error")