"""
    website url --> www.flipkart.com
    request
            response

    client server architecture

    HTTP BASICS

    BROWSER --> HTTP REQUEST --> WEBSITE --> HTTP RESPONSE --> BROWSER

    REQUEST

    GET , POST , PUT , DELETE , PATCH
    GET --> getting info
    POST --> REQUEST --> DATA SEND

    RESPONSE
        --> status code
            200 --> ok request succeeded
            403 --> forbidden
            404 --> not found

    REQUESTS

    install --> pip install requests

"""
import requests

url = input("\n Enter Website URL Example: (https://www.example.com): ").strip()

# make requests

response = requests.get(url)

# print status code
print(response.status_code)

# print headers
print(response.headers)

# print cookies
print(response.cookies)

# print content
print(response.content)

# print text
print(response.text)






